# Telegram Bot Oyunları
Bu repo, Bots.Business için 90 farklı oyun komutu içeren bir Telegram botu içindir.

## 📂 Klasör Yapısı
- `/Oyunlar/Kelime_Oyunu/kelime_oyunu.json`
- `/Oyunlar/Matematik_Oyunu/matematik_oyunu.json`
- `/Oyunlar/Ağaç_Kesme/agac_kesme.json`
- ... (Toplam 90 oyun)

## 🚀 Kullanım
1. GitHub'a yükleyin.
2. Bots.Business'ta JSON dosyalarını içe aktarın.
3. Botunuzu başlatın!

🎮 Eğlenceli oyunlar! 🚀
